#include <stdio.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdint.h>
#include <string.h>
#include <stddef.h>
#include <stdbool.h>

// Header struct linked list for containing memory blocks
struct mem_node
{
  size_t size;
  bool free; 
  struct mem_node *p_node, *n_node;
};

typedef struct mem_node *mem_chunk;

// A collection of macros for tedious tasks
#define NODE_SIZE sizeof(struct mem_node)            // mem_node size shorthand
#define GOOD_ENOUGH_FIT 32         // Setting for selective splitting of chunks
#define incr_node(node) node = node->n_node
#define decr_node(node) node = node->p_node
#define set_next_link(node, new_node) node->n_node->p_node = new_node
#define set_prev_link(node, new_node) node->p_node->n_node = new_node
#define pad(n) ((n % 8) == 0) ? (n):(((n / 8) + 1) * 8)

 void *new_chunk(void *, mem_chunk, mem_chunk, size_t, bool);

void *calloc(size_t , size_t);


void split(size_t, mem_chunk);
void free(void *);