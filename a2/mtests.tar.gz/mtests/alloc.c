/*
 * CS 2240 - Assignment 2
 * Implementation of malloc(), calloc(), realloc(), and free() using sbrk()
 * John Lewis
 *
 * This file contain malloc(), calloc(), realloc(), and free(), 
 * as well as any helper functions, macros, etc. they need.
 */

#include "alloc.h"
//#include <stdlib.h>



/*
 * The logic for creating a new mem_chunk is repeated several places, 
 * better to put it into a function for brevity.
 */
 void *new_chunk(void *eq, mem_chunk prev, mem_chunk next, size_t size,
  bool freep)
{
  mem_chunk new_chunk = eq;
  new_chunk->p_node = prev;
  new_chunk->n_node = next;
  new_chunk->size = size;
  new_chunk->free = freep;
  return new_chunk;
}

/*
 * Attempts to find a free chunk in the linked list
 */
static mem_chunk blank = NULL;
 static void *find_free(mem_chunk *node, size_t size)
{
  if (blank == NULL)
    blank = new_chunk(sbrk(pad(NODE_SIZE)), NULL, NULL, 0, true);
  mem_chunk free_nd = blank;

  while (free_nd != NULL && (free_nd->free == true || (free_nd->size < size)))
  {
    *node = free_nd;
    incr_node(free_nd);
  }
  return free_nd;
}

/*
 * Modifies the linked list by inserting a new node in front of node, and doing
 * all the neccessary opreations so that the older node points to the new node.
 */
  void split(size_t mem_size, mem_chunk node)
{
  mem_chunk temp;
  temp = new_chunk(((void *)node + mem_size), node, node->n_node,
    node->size - mem_size, false);

  if (node->n_node != NULL)
    set_next_link(node, temp);
  node->n_node = temp;
  node->size = mem_size - NODE_SIZE;
}

/*
 * Merge the mem_chunk node with its next node
 */
  void merge(mem_chunk node) 
{
  node->size += node->n_node->size + NODE_SIZE;
  incr_node(node->n_node);
  if (node->n_node != NULL) 
    set_next_link(node, node);
}

/*
 * Simple coalescing scheme. I don't have a way with the current formulation
 * to simply swap the pieces in memory at will (the users' pointers wouldn't
 * be right.) So for now, this may be applied when a user realloc()s memory.
 * If the node's previous node and next node are free, we can swap it back
 * and merge the two free blocks.
 */
  void try_coalesce(void *ptr)
{
  mem_chunk node = (mem_chunk) ptr - 1;
  // If the next and previous nodes don't exist or aren't free, return
  if (node->p_node == NULL || node->n_node == NULL || 
    node->p_node->free == false || node->n_node->free == false)
    return;

  mem_chunk prev = node->p_node;
  mem_chunk prev_p_node = prev->p_node;
  size_t prev_size = prev->size;
  mem_chunk next = node->n_node;

  memmove(node->p_node - 1, node, node->size + 1);

  node->p_node = prev_p_node;   // Connect the previous node to node
  set_prev_link(node, node);
  node->n_node = prev;                       // Connect node to prev
  set_next_link(node, node);
  prev->size = prev_size;
  prev->n_node = next;                      // Connect next to prev
  set_next_link(prev, prev);

  merge(prev);
}

/*
 * Simple implementation of malloc()
 */
void *malloc(size_t size)
{
  //fprintf(stderr,"Called malloc\n");

  // If the size requested is null, simply return NULL.
  if (size == 0)
    return NULL;
  /* 
   * Calculate the size of the required chunk, making sure to pad the size
   * so that it aligns in memory to the next highest multiple of 8 bytes. 
   */
  size_t mem_size = pad(size + NODE_SIZE);
  mem_chunk prev_chunk = NULL;
  mem_chunk cur_chunk = find_free(&prev_chunk, mem_size);

  // GOOD_ENOUGH_FIT is so we can have a selective split.
  int fit_size = mem_size + sizeof(size_t) + GOOD_ENOUGH_FIT;
  if (cur_chunk != NULL && fit_size < cur_chunk->size)
    split(mem_size, cur_chunk);
  else if (cur_chunk == NULL)
  {
    mem_chunk temp = new_chunk(sbrk(mem_size), prev_chunk, NULL,
      mem_size - NODE_SIZE, true);
    prev_chunk->n_node = temp;
    cur_chunk = temp;
  }

  cur_chunk->free = true;
  return cur_chunk + 1;      // Return a pointer to just past the header struct
}

/*
 * Simple implementation of calloc()
 */
void *calloc(size_t count, size_t size)
{
  size_t mem_size = count * size;
  void *mem_ptr = malloc(mem_size);   // Use malloc as usual for the allocation
  memset(mem_ptr, 0x00, mem_size);            // memset() mem_ptr to 0x00 bytes
  return mem_ptr;
}

/*
 * Simple implementation of realloc()
 */
void *realloc(void *ptr, size_t size)
{
  /* 
   * If size is equal to zero, and ptr is not NULL, then the call is equivalent
   * to free(ptr). If the ptr is outside the program break, return NULL.
   */
  if ((size == 0 && ptr != NULL) || ptr >= sbrk(0))
  {
    if (ptr < sbrk(0))
      free(ptr);
    return NULL;
  }
  mem_chunk old_ptr = (mem_chunk) ptr - 1;    // cast ptr param to mem_chunk
  void *realloc_ptr = malloc(size);          // malloc() space for required ptr

  if (ptr == NULL)    // If ptr is null, the call is equivalent to malloc(size)
    return realloc_ptr;

  size_t realloc_len;   // Logic to handle the case of growing or shrinking ptr
  if (old_ptr->size < size)
    realloc_len = old_ptr->size;
  else
    realloc_len = size;

  memcpy(realloc_ptr, ptr, realloc_len);
  free(ptr);
  // I couldn't get try_coalesce to work
  //try_coalesce(realloc_ptr);
  return realloc_ptr;
}

/*
 * Simple implementation of free()
 */
void free(void *ptr)
{
  /*
   * If the ptr is null, return. If the ptr has already been freed, glibc says
   * for their free() that undefined behavior will occur. I'll return instead.
   */
  mem_chunk node = (mem_chunk) ptr - 1;
  if (ptr == NULL || node->free == false)
    return;
  node->free = false;                      // mark the node's free flag as free

  /*
   * Check back and forth through the linked list for free nodes and merge if:
   * - They are not null
   * - They are less than the current program break
   * - They are free
   */
  mem_chunk temp = node;
  while (node->n_node && (void *)node < sbrk(0) && node->n_node->free == false)
  {
    merge(temp);
    incr_node(temp);
  }
  while (node->p_node && (void *)node < sbrk(0) && node->p_node->free == false)
  {
    decr_node(node);
    merge(node);
  }

  // Reduce the program break if needed.
  if (node->n_node == NULL)
  {
    size_t size = (-1 * (node->size + NODE_SIZE));
    set_prev_link(node, NULL);
    sbrk(size);
  }
}
